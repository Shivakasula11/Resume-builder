import { useState, useRef, useCallback, useEffect } from "react";

const API_BASE = "http://localhost:8000";

/* ICONS */
const Icons = {
  Upload: () => <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 12 15 15"/></svg>,
  Download: () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  Edit: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
  Check: () => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  X: () => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Reset: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>,
  Search: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  Sparkle: () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  File: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  Plus: () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Target: () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
  ChevronDown: () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>,
};

/* ═══════════════════════════════════════════
   AI COMPARISON COMPONENTS
   ═══════════════════════════════════════════ */

/* SCORE RING */
function ScoreRing({ score, size = 120, strokeWidth = 10 }) {
  const r = (size - strokeWidth) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const color = score >= 70 ? "#059669" : score >= 50 ? "#d97706" : "#dc2626";
  return (
    <div style={{ position: "relative", width: size, height: size, margin: "0 auto" }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#f1f5f9" strokeWidth={strokeWidth} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 1s ease" }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <span style={{ fontSize: size * 0.28, fontWeight: 800, color, lineHeight: 1 }}>{score}%</span>
        <span style={{ fontSize: size * 0.09, color: "#9ca3af", fontWeight: 600, marginTop: 2 }}>MATCH</span>
      </div>
    </div>
  );
}

/* SKILL TAG */
function SkillTag({ skill, found, frequency }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 9px", borderRadius: 6,
      fontSize: 10.5, fontWeight: 600,
      background: found ? "#ecfdf5" : "#fef2f2",
      color: found ? "#065f46" : "#991b1b",
      border: `1px solid ${found ? "#a7f3d0" : "#fecaca"}`,
      marginBottom: 4, marginRight: 4,
    }}>
      {found ? "✓" : "✗"} {skill}
      {frequency && <span style={{ fontSize: 9, color: found ? "#10b981" : "#f87171", fontWeight: 700 }}>{frequency}%</span>}
    </span>
  );
}

/* COMPARISON PANEL */
function ComparisonPanel({ sessionId, onClose }) {
  const [role, setRole] = useState("");
  const [level, setLevel] = useState("fresher");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [expandedCat, setExpandedCat] = useState(null);
  const [downloading, setDownloading] = useState(false);

  const runComparison = async () => {
    if (!role.trim()) return;
    setLoading(true); setError(""); setResult(null);
    try {
      const resp = await fetch(`${API_BASE}/ai/compare`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, role: role.trim(), level }),
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.detail || "Comparison failed");
      }
      setResult(await resp.json());
    } catch (err) {
      setError(err.message || "Failed. Check backend & OpenAI key.");
    }
    setLoading(false);
  };

  const downloadReport = async () => {
    setDownloading(true);
    try {
      const resp = await fetch(`${API_BASE}/ai/compare-report`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, role: role.trim(), level }),
      });
      if (!resp.ok) throw new Error("Report generation failed");
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `resume_vs_${role.trim().replace(/\s+/g, "_")}_report.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err.message);
    }
    setDownloading(false);
  };

  const s80 = result?.threshold_80 || {};
  const s70 = result?.threshold_70 || {};
  const catScores = result?.category_scores || {};

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, width: 440, height: "100vh", zIndex: 1000,
      background: "#fff", boxShadow: "-4px 0 30px rgba(0,0,0,0.12)",
      display: "flex", flexDirection: "column", fontFamily: "'Manrope',sans-serif",
      animation: "slideIn 0.3s ease",
    }}>
      <style>{`@keyframes slideIn{from{transform:translateX(100%)}to{transform:translateX(0)}}`}</style>

      {/* Header */}
      <div style={{
        padding: "16px 20px", borderBottom: "1px solid #e5e7eb",
        background: "linear-gradient(135deg,#faf5ff,#f0f9ff)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Icons.Target />
          <span style={{ fontWeight: 800, fontSize: 15, color: "#111827" }}>AI Resume Match</span>
        </div>
        <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#6b7280", padding: 4 }}>
          <Icons.X />
        </button>
      </div>

      {/* Level Toggle */}
      <div style={{ padding: "14px 20px", borderBottom: "1px solid #f1f5f9", background: "#fafbfc" }}>
        <label style={{ fontSize: 11, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8, display: "block" }}>
          Experience Level
        </label>
        <div style={{ display: "flex", gap: 0, borderRadius: 10, overflow: "hidden", border: "1.5px solid #e2e8f0" }}>
          {[
            { val: "fresher", label: "🎓 Fresher", desc: "0-1 yr" },
            { val: "experienced", label: "💼 Experienced", desc: "2+ yrs" },
          ].map(opt => (
            <button key={opt.val} onClick={() => { setLevel(opt.val); setResult(null); }}
              style={{
                flex: 1, padding: "10px 8px", border: "none", cursor: "pointer",
                fontFamily: "inherit", fontSize: 12, fontWeight: level === opt.val ? 700 : 500,
                background: level === opt.val
                  ? (opt.val === "fresher" ? "linear-gradient(135deg,#059669,#10b981)" : "linear-gradient(135deg,#7c3aed,#6366f1)")
                  : "#fff",
                color: level === opt.val ? "#fff" : "#6b7280",
                transition: "all 0.2s",
              }}>
              {opt.label}<br/>
              <span style={{ fontSize: 10, opacity: 0.8 }}>{opt.desc}</span>
            </button>
          ))}
        </div>
        <p style={{ fontSize: 10, color: "#9ca3af", marginTop: 6, lineHeight: 1.4 }}>
          {level === "fresher"
            ? "Skills tailored for entry-level roles. No experience/advanced degree requirements."
            : "Includes experience requirements, advanced education, and senior-level skills."}
        </p>
      </div>

      {/* Role Input */}
      <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
        <label style={{ fontSize: 11, fontWeight: 700, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8, display: "block" }}>
          Job Role
        </label>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            value={role}
            onChange={(e) => setRole(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") runComparison(); }}
            placeholder="e.g. AIML Developer, Full Stack Engineer..."
            style={{
              flex: 1, padding: "10px 14px", borderRadius: 10, border: "1.5px solid #e2e8f0",
              fontSize: 13, fontFamily: "inherit", outline: "none", color: "#111827", background: "#fafbfc",
            }}
          />
          <button onClick={runComparison} disabled={loading || !role.trim()}
            style={{
              padding: "10px 20px", borderRadius: 10, border: "none", fontWeight: 700, fontSize: 12,
              fontFamily: "inherit", cursor: loading || !role.trim() ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", gap: 6,
              background: loading ? "#94a3b8" : "linear-gradient(135deg,#7c3aed,#6366f1)", color: "#fff",
              boxShadow: loading ? "none" : "0 2px 10px rgba(99,102,241,0.3)",
            }}>
            {loading ? (
              <>
                <span style={{
                  width: 14, height: 14, border: "2px solid #fff4", borderTop: "2px solid #fff",
                  borderRadius: "50%", animation: "spin 0.8s linear infinite", display: "inline-block",
                }} />
                Analyzing...
              </>
            ) : (
              <><Icons.Target /> Compare</>
            )}
          </button>
        </div>
        {error && <p style={{ fontSize: 11, color: "#dc2626", marginTop: 8, fontWeight: 600 }}>⚠ {error}</p>}
      </div>

      {/* Results Area */}
      <div style={{ flex: 1, overflowY: "auto", padding: loading ? "40px 20px" : result ? "0" : "40px 20px" }}>

        {/* Loading */}
        {loading && (
          <div style={{ textAlign: "center" }}>
            <div style={{
              width: 50, height: 50, border: "3px solid #e5e7eb", borderTop: "3px solid #6366f1",
              borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px",
            }} />
            <p style={{ fontSize: 14, fontWeight: 700, color: "#4b5563" }}>Analyzing your resume...</p>
            <p style={{ fontSize: 12, color: "#9ca3af", marginTop: 4 }}>AI is extracting skills and comparing against role requirements</p>
          </div>
        )}

        {/* Empty state */}
        {!loading && !result && !error && (
          <div style={{ textAlign: "center", color: "#9ca3af" }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🎯</div>
            <p style={{ fontSize: 14, fontWeight: 600, color: "#6b7280" }}>Enter a job role to compare</p>
            <p style={{ fontSize: 12, marginTop: 6, lineHeight: 1.6 }}>
              AI will analyze what skills are typically required for that role and check how well your resume matches.
            </p>
          </div>
        )}

        {/* Results */}
        {result && (
          <div>
            {/* Score Section */}
            <div style={{
              padding: "24px 20px", textAlign: "center",
              background: "linear-gradient(180deg,#faf5ff 0%,#fff 100%)",
              borderBottom: "1px solid #f1f5f9",
            }}>
              <ScoreRing score={result.overall_score} />
              <p style={{ fontSize: 13, color: "#6b7280", marginTop: 12 }}>
                <strong style={{ color: "#111827" }}>{result.role}</strong>
                <span style={{
                  marginLeft: 8, fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 10,
                  background: result.level === "fresher" ? "#ecfdf5" : "#f3e8ff",
                  color: result.level === "fresher" ? "#059669" : "#7c3aed",
                }}>{result.level === "fresher" ? "🎓 Fresher" : "💼 Experienced"}</span>
              </p>
              {result.role_description && (
                <p style={{ fontSize: 11, color: "#9ca3af", marginTop: 4, lineHeight: 1.5 }}>{result.role_description}</p>
              )}
              <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 16 }}>
                {[
                  { n: result.resume_skills_count, l: "YOUR SKILLS", bg: "#f1f5f9", c: "#111827" },
                  { n: result.role_skills_count, l: "ROLE NEEDS", bg: "#f1f5f9", c: "#111827" },
                  { n: s80.matched_count || 0, l: "MATCHED", bg: "#ecfdf5", c: "#059669" },
                  { n: s80.missing_count || 0, l: "MISSING", bg: "#fef2f2", c: "#dc2626" },
                ].map((x, i) => (
                  <div key={i} style={{ padding: "8px 14px", borderRadius: 8, background: x.bg }}>
                    <div style={{ fontSize: 18, fontWeight: 800, color: x.c }}>{x.n}</div>
                    <div style={{ fontSize: 9, color: "#6b7280", fontWeight: 600 }}>{x.l}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tier Breakdown */}
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
              <h3 style={{ fontSize: 12, fontWeight: 800, color: "#374151", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Score Breakdown
              </h3>
              {[
                { label: "Must-Have (80%+)", data: s80, color: "#dc2626" },
                { label: "Important (70%+)", data: s70, color: "#d97706" },
                { label: "All Skills", data: result.all_skills || {}, color: "#6366f1" },
              ].map(({ label, data, color }) => (
                <div key={label} style={{ marginBottom: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                    <span style={{ fontSize: 11, fontWeight: 600, color: "#4b5563" }}>{label}</span>
                    <span style={{ fontSize: 12, fontWeight: 800, color }}>{data.score || 0}%</span>
                  </div>
                  <div style={{ height: 6, borderRadius: 3, background: "#f1f5f9", overflow: "hidden" }}>
                    <div style={{ height: "100%", borderRadius: 3, background: color, width: `${data.score || 0}%`, transition: "width 1s ease" }} />
                  </div>
                  <div style={{ fontSize: 10, color: "#9ca3af", marginTop: 2 }}>
                    {data.matched_count || 0} of {data.total_skills || 0} matched
                  </div>
                </div>
              ))}
            </div>

            {/* Category Breakdown */}
            {Object.keys(catScores).length > 0 && (
              <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
                <h3 style={{ fontSize: 12, fontWeight: 800, color: "#374151", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  By Category
                </h3>
                {Object.entries(catScores)
                  .sort((a, b) => a[1].score - b[1].score)
                  .map(([cat, info]) => {
                    const cc = info.score >= 70 ? "#059669" : info.score >= 40 ? "#d97706" : "#dc2626";
                    const isExp = expandedCat === cat;
                    return (
                      <div key={cat} style={{ marginBottom: 6 }}>
                        <div
                          onClick={() => setExpandedCat(isExp ? null : cat)}
                          style={{
                            display: "flex", alignItems: "center", gap: 8, padding: "6px 8px",
                            borderRadius: 6, cursor: "pointer", background: isExp ? "#f9fafb" : "transparent",
                          }}>
                          <span style={{ transform: isExp ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.2s" }}>
                            <Icons.ChevronDown />
                          </span>
                          <span style={{ fontSize: 11, fontWeight: 600, color: "#374151", flex: 1, textTransform: "capitalize" }}>
                            {cat.replace("_", " ")}
                          </span>
                          <span style={{ fontSize: 10, color: "#9ca3af" }}>{info.matched}/{info.total}</span>
                          <span style={{ fontSize: 11, fontWeight: 800, color: cc, minWidth: 36, textAlign: "right" }}>{info.score}%</span>
                        </div>
                        {isExp && info.skills && (
                          <div style={{ padding: "8px 12px 8px 28px" }}>
                            {info.skills.map((s, i) => (
                              <SkillTag key={i} skill={s.skill} found={s.found} frequency={s.frequency} />
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
              </div>
            )}

            {/* Missing Must-Have Skills */}
            {s80.missing?.length > 0 && (
              <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
                <h3 style={{ fontSize: 12, fontWeight: 800, color: "#dc2626", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  ❌ Missing Must-Have ({s80.missing.length})
                </h3>
                <div style={{ display: "flex", flexWrap: "wrap" }}>
                  {s80.missing.map((s, i) => <SkillTag key={i} skill={s.skill} found={false} frequency={s.frequency} />)}
                </div>
              </div>
            )}

            {/* Matched Must-Have Skills */}
            {s80.matched?.length > 0 && (
              <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
                <h3 style={{ fontSize: 12, fontWeight: 800, color: "#059669", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  ✅ Matched Must-Have ({s80.matched.length})
                </h3>
                <div style={{ display: "flex", flexWrap: "wrap" }}>
                  {s80.matched.map((s, i) => <SkillTag key={i} skill={s.skill} found={true} frequency={s.frequency} />)}
                </div>
              </div>
            )}

            {/* Bonus Skills */}
            {result.extra_skills?.length > 0 && (
              <div style={{ padding: "16px 20px", borderBottom: "1px solid #f1f5f9" }}>
                <h3 style={{ fontSize: 12, fontWeight: 800, color: "#6366f1", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  💡 Your Bonus Skills ({result.extra_skills.length})
                </h3>
                <p style={{ fontSize: 10.5, color: "#9ca3af", marginBottom: 8 }}>In your resume but not commonly required for this role</p>
                <div style={{ display: "flex", flexWrap: "wrap" }}>
                  {result.extra_skills.slice(0, 20).map((s, i) => (
                    <span key={i} style={{
                      display: "inline-block", padding: "3px 9px", borderRadius: 6, fontSize: 10.5, fontWeight: 600,
                      background: "#eef2ff", color: "#4338ca", border: "1px solid #c7d2fe", marginBottom: 4, marginRight: 4,
                    }}>
                      {s.skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Download PDF Report */}
            <div style={{ padding: "20px", textAlign: "center" }}>
              <button onClick={downloadReport} disabled={downloading}
                style={{
                  padding: "12px 28px", borderRadius: 10, border: "none", fontWeight: 700, fontSize: 13,
                  fontFamily: "inherit", cursor: downloading ? "wait" : "pointer",
                  background: downloading ? "#94a3b8" : "linear-gradient(135deg,#7c3aed,#6366f1)", color: "#fff",
                  boxShadow: "0 3px 14px rgba(99,102,241,0.25)", display: "inline-flex", alignItems: "center", gap: 8,
                }}>
                <Icons.Download /> {downloading ? "Generating..." : "Download PDF Report"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   EXISTING COMPONENTS (unchanged)
   ═══════════════════════════════════════════ */

/* MINI RICH TEXT EDITOR - select text + click B or Ctrl+B */
function RichEditor({ onSubmit, onCancel, adding }) {
  const editorRef = useRef(null);

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.focus();
    }
  }, []);

  const toggleBold = () => {
    document.execCommand("bold", false, null);
    editorRef.current?.focus();
  };

  const getSegments = () => {
    const el = editorRef.current;
    if (!el) return [];
    const segments = [];

    const walk = (node, isBold) => {
      if (node.nodeType === 3) { // text node
        if (node.textContent) segments.push({ text: node.textContent, bold: isBold });
      } else if (node.nodeType === 1) { // element
        const tag = node.tagName?.toLowerCase();
        const nowBold = isBold || tag === "b" || tag === "strong" ||
          (node.style && (node.style.fontWeight === "bold" || parseInt(node.style.fontWeight) >= 700));
        for (const child of node.childNodes) walk(child, nowBold);
      }
    };
    walk(el, false);

    // Merge adjacent segments with same bold state
    const merged = [];
    for (const seg of segments) {
      if (merged.length > 0 && merged[merged.length - 1].bold === seg.bold) {
        merged[merged.length - 1].text += seg.text;
      } else {
        merged.push({ ...seg });
      }
    }
    return merged;
  };

  const handleSubmit = () => {
    const segs = getSegments();
    if (segs.some(s => s.text.trim())) onSubmit(segs);
  };

  const handleKeyDown = (e) => {
    if (e.key === "b" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      toggleBold();
    }
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
    if (e.key === "Escape") onCancel();
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
        <button onClick={toggleBold} title="Bold (Ctrl+B)"
          style={{ padding: "3px 10px", borderRadius: 5, fontSize: 12, fontWeight: 900, cursor: "pointer",
            fontFamily: "serif", background: "#f3f4f6", color: "#374151", border: "1.5px solid #d1d5db",
            lineHeight: 1 }}
          onMouseDown={(e) => e.preventDefault()}>B</button>
        <span style={{ fontSize: 10, color: "#a8a29e" }}>Select text → click B or Ctrl+B</span>
      </div>
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onKeyDown={handleKeyDown}
        style={{ minHeight: 44, padding: "8px 10px", border: "1.5px solid #e2e8f0", borderRadius: 8, fontSize: 12,
          fontFamily: "'Manrope',sans-serif", background: "#fff", outline: "none", lineHeight: 1.6, color: "#1a1a2e",
          cursor: "text" }}
        data-placeholder="Type here, select text and press B to bold..."
      />
      <style>{`[contenteditable]:empty:before{content:attr(data-placeholder);color:#aaa;pointer-events:none}`}</style>
      <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
        <button onClick={onCancel} style={{ padding: "4px 12px", borderRadius: 6, border: "1px solid #e2e8f0",
          background: "#fff", cursor: "pointer", fontSize: 11, fontFamily: "inherit", color: "#64748b" }}>Cancel</button>
        <button onClick={handleSubmit} disabled={adding}
          style={{ padding: "4px 14px", borderRadius: 6, border: "none",
            background: adding ? "#94a3b8" : "#d97706", color: "#fff", cursor: adding ? "wait" : "pointer",
            fontSize: 11, fontFamily: "inherit", fontWeight: 700 }}>{adding ? "Adding..." : "Add Line"}</button>
      </div>
    </div>
  );
}

/* ADD LINE INLINE FORM */
function AddLineForm({ field, onAdd, onCancel, adding }) {
  const snippet = field.text.slice(0, 40) + (field.text.length > 40 ? "..." : "");

  const handleRichSubmit = (segments) => {
    onAdd(field, { segments });
  };

  return (
    <div style={{ padding: "8px 12px", background: "#fefce8", borderRadius: 8, border: "1.5px solid #fde68a", marginBottom: 3 }}>
      <div style={{ fontSize: 10, color: "#92400e", fontWeight: 700, marginBottom: 8 }}>
        ＋ ADD AFTER: <span style={{ fontWeight: 400, color: "#78716c" }}>{snippet}</span>
      </div>
      <RichEditor onSubmit={handleRichSubmit} onCancel={onCancel} adding={adding} />
    </div>
  );
}

/* FIELD ROW */
function FieldRow({ field, onSave, onAddLine, saving, onReplaceImage, onEditBar }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(field.text);
  const inputRef = useRef(null);
  const imgInputRef = useRef(null);
  const isModified = field.text !== field.originalText;

  useEffect(() => { setValue(field.text); }, [field.text]);
  useEffect(() => { if (editing && inputRef.current) { inputRef.current.focus(); inputRef.current.select?.(); } }, [editing]);

  const save = () => { if (value.trim() && value !== field.text) onSave(field, value.trim()); setEditing(false); };
  const cancel = () => { setValue(field.text); setEditing(false); };

  const color = field.section?.color || "#64748b";

  if (field.isHeader) {
    if (editing) {
      return (
        <div style={{ padding: "8px 10px", background: `${color}10`, borderRadius: 8, marginTop: 10, border: `1.5px solid ${color}40` }}>
          <input ref={inputRef} value={value} onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") cancel(); }}
            style={{ width: "100%", fontSize: 12, fontWeight: 800, fontFamily: "inherit", border: "none", outline: "none",
              background: "transparent", color, textTransform: "uppercase", letterSpacing: "0.07em", padding: "2px 0" }} />
          <div style={{ display: "flex", gap: 6, marginTop: 6, justifyContent: "flex-end" }}>
            <button onClick={cancel} style={{ padding: "3px 10px", borderRadius: 5, border: "1px solid #e5e7eb",
              background: "#fff", cursor: "pointer", fontSize: 11, fontFamily: "inherit", color: "#6b7280" }}>Cancel</button>
            <button onClick={save} disabled={saving} style={{ padding: "3px 10px", borderRadius: 5, border: "none",
              background: color, color: "#fff", cursor: "pointer", fontSize: 11, fontFamily: "inherit", fontWeight: 700 }}>
              {saving ? "..." : "Apply"}</button>
          </div>
        </div>
      );
    }
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 0 5px", marginTop: 10 }}>
        <div style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
        <span onClick={() => setEditing(true)} style={{ fontSize: 11, fontWeight: 800, color, textTransform: "uppercase", letterSpacing: "0.07em", flex: 1, cursor: "pointer" }}>{field.text}</span>
        <span onClick={() => setEditing(true)} style={{ color: "#c8cdd5", flexShrink: 0, opacity: 0.4, cursor: "pointer" }}><Icons.Edit /></span>
        <button onClick={() => onAddLine(field)} title="Add line after this section header"
          style={{ background: "none", border: "1px solid #e2e8f0", borderRadius: 5, cursor: "pointer", padding: "2px 5px",
            color: "#9ca3af", display: "flex", alignItems: "center", opacity: 0.6 }}
          onMouseEnter={e => { e.currentTarget.style.opacity = 1; e.currentTarget.style.borderColor = color; e.currentTarget.style.color = color; }}
          onMouseLeave={e => { e.currentTarget.style.opacity = 0.6; e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.color = "#9ca3af"; }}>
          <Icons.Plus />
        </button>
      </div>
    );
  }

  // Image field
  if (field.type === "image") {
    return (
      <div style={{
        padding: "8px 10px", background: isModified ? "#fef3c710" : "#f8fafc", borderRadius: 8, marginBottom: 3,
        border: isModified ? "1px solid #c026d325" : "1px solid #e2e8f0",
        display: "flex", gap: 8, alignItems: "center",
      }}>
        <span style={{ fontSize: 18 }}>📷</span>
        <span style={{ fontSize: 12, color: "#334155", flex: 1 }}>{field.text}</span>
        <input ref={imgInputRef} type="file" accept="image/*" style={{ display: "none" }}
          onChange={(e) => { if (e.target.files?.[0] && onReplaceImage) onReplaceImage(field, e.target.files[0]); e.target.value = ""; }} />
        <button onClick={() => imgInputRef.current?.click()} disabled={saving}
          style={{ padding: "4px 10px", borderRadius: 6, border: "1px solid #c026d340", background: "#fdf4ff",
            cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit", color: "#a21caf",
            display: "flex", alignItems: "center", gap: 4 }}>
          📎 Replace
        </button>
      </div>
    );
  }

  // Progress bar field
  if (field.type === "progress-bar") {
    const pctNum = parseInt(field.text) || 0;
    return (
      <div style={{
        padding: "8px 10px", background: isModified ? `${color}08` : "#f8fafc", borderRadius: 8, marginBottom: 3,
        border: isModified ? `1px solid ${color}25` : "1px solid #e2e8f0",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
          <span style={{ fontSize: 9, fontWeight: 700, color: "#6366f1", background: "#eef2ff", padding: "1px 5px", borderRadius: 3 }}>📊</span>
          <span style={{ fontSize: 11, color: "#475569", fontWeight: 600, flex: 1 }}>{field.barLabel}</span>
          <span style={{ fontSize: 12, fontWeight: 800, color, minWidth: 32, textAlign: "right" }}>{value}</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <input type="range" min="1" max="100" value={parseInt(value) || 0}
            onChange={(e) => setValue(e.target.value + "%")}
            style={{ flex: 1, accentColor: color, cursor: "pointer" }} />
          <button onClick={() => { if (onEditBar) onEditBar(field, parseInt(value) || 0); }}
            disabled={saving || value === field.text}
            style={{ padding: "3px 8px", borderRadius: 5, border: "none",
              background: value !== field.text ? color : "#e2e8f0",
              color: value !== field.text ? "#fff" : "#94a3b8",
              cursor: value !== field.text ? "pointer" : "default",
              fontSize: 10, fontWeight: 700, fontFamily: "inherit" }}>
            {saving ? "..." : "Apply"}
          </button>
        </div>
      </div>
    );
  }

  if (editing) {
    return (
      <div style={{ padding: "10px 12px", background: "#fff", borderRadius: 10, border: `1.5px solid ${color}40`, marginBottom: 5, boxShadow: `0 3px 14px ${color}12` }}>
        <div style={{ display: "flex", gap: 6, marginBottom: 8, flexWrap: "wrap" }}>
          {field.isBold && <span style={{ fontSize: 10, fontWeight: 800, color: "#92400e", background: "#fef3c7", padding: "2px 8px", borderRadius: 4 }}>BOLD</span>}
          <span style={{ fontSize: 10, color: "#6b7280", background: "#f3f4f6", padding: "2px 8px", borderRadius: 4 }}>{field.format}</span>
        </div>
        {field.text.length > 100 ? (
          <textarea ref={inputRef} value={value} onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Escape") cancel(); }}
            rows={Math.min(6, Math.ceil(field.text.length / 60))}
            style={{ width: "100%", padding: "8px 10px", border: "1.5px solid #e2e8f0", borderRadius: 8, fontSize: 12,
              fontFamily: "'Manrope',sans-serif", resize: "vertical", background: "#fafbfc", outline: "none", lineHeight: 1.6, color: "#1a1a2e" }} />
        ) : (
          <input ref={inputRef} value={value} onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") cancel(); }}
            style={{ width: "100%", padding: "8px 10px", border: "1.5px solid #e2e8f0", borderRadius: 8, fontSize: 12,
              fontFamily: "'Manrope',sans-serif", background: "#fafbfc", outline: "none", color: "#1a1a2e" }} />
        )}
        <div style={{ display: "flex", gap: 6, marginTop: 8, justifyContent: "flex-end" }}>
          <button onClick={cancel} style={{ padding: "5px 12px", borderRadius: 6, border: "1px solid #e2e8f0",
            background: "#fff", cursor: "pointer", fontSize: 11.5, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 4, color: "#64748b" }}>
            <Icons.X /> Cancel</button>
          <button onClick={save} disabled={saving} style={{ padding: "5px 14px", borderRadius: 6, border: "none",
            background: saving ? "#94a3b8" : color, color: "#fff", cursor: saving ? "wait" : "pointer",
            fontSize: 11.5, fontFamily: "inherit", fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}>
            <Icons.Check /> {saving ? "Saving..." : "Apply"}</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      padding: "7px 10px", background: isModified ? `${color}08` : "#fff", borderRadius: 8, marginBottom: 3, cursor: "pointer",
      border: isModified ? `1px solid ${color}25` : "1px solid #f1f5f9", transition: "all 0.15s",
      display: "flex", gap: 8, alignItems: "flex-start",
    }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = `${color}40`; e.currentTarget.style.background = `${color}06`; e.currentTarget.querySelector('.add-btn').style.opacity = 0.6; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = isModified ? `${color}25` : "#f1f5f9"; e.currentTarget.style.background = isModified ? `${color}08` : "#fff"; e.currentTarget.querySelector('.add-btn').style.opacity = 0; }}
    >
      {isModified && <span style={{ width: 6, height: 6, borderRadius: "50%", marginTop: 5, flexShrink: 0, background: color }} />}
      {field.isBold && <span style={{ fontSize: 9, fontWeight: 800, color: "#92400e", background: "#fef3c7", padding: "1px 5px", borderRadius: 3, flexShrink: 0, marginTop: 2 }}>B</span>}
      {field.type === "icon-link" && <span style={{ fontSize: 9, fontWeight: 700, color: "#1d4ed8", background: "#dbeafe", padding: "1px 5px", borderRadius: 3, flexShrink: 0, marginTop: 2 }}>🔗 {field.linkLabel || "Link"}</span>}
      <span onClick={() => setEditing(true)} style={{ fontSize: 12, color: field.type === "icon-link" ? "#2563eb" : "#334155", lineHeight: 1.55, flex: 1, overflow: "hidden", textOverflow: "ellipsis",
        display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
        fontWeight: field.isBold ? 700 : 400, wordBreak: field.type === "icon-link" ? "break-all" : "normal" }}>{field.text}</span>
      <span onClick={() => setEditing(true)} style={{ color: "#c8cdd5", flexShrink: 0, marginTop: 1, opacity: 0.6 }}><Icons.Edit /></span>
      <button className="add-btn"
        onClick={(e) => { e.stopPropagation(); onAddLine(field); }}
        title="Add line after this"
        style={{ background: "none", border: "none", cursor: "pointer", padding: "1px 2px",
          color: "#d97706", flexShrink: 0, marginTop: 1, opacity: 0, transition: "opacity 0.15s" }}>
        <Icons.Plus />
      </button>
    </div>
  );
}

/* ═══════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════ */
export default function ResumeEditor() {
  const [view, setView] = useState("upload");
  const [fileName, setFileName] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editCount, setEditCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusMsg, setStatusMsg] = useState("");
  const [fields, setFields] = useState([]);
  const [backendOk, setBackendOk] = useState(null);
  const [addingAfter, setAddingAfter] = useState(null);
  const [convertedFromPdf, setConvertedFromPdf] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const fileInputRef = useRef(null);
  const [previewVer, setPreviewVer] = useState(0);
  const docxPreviewRef = useRef(null);
  const previewRef = useRef(null);

  useEffect(() => {
    fetch(`${API_BASE}/health`).then(r => r.json()).then((d) => {
      setBackendOk(true);
    }).catch(() => setBackendOk(false));
  }, []);

  const loadDocxPreview = useCallback(async () => {
    if (!docxPreviewRef.current) {
      const mod = await import("https://cdn.jsdelivr.net/npm/docx-preview@0.3.7/+esm");
      docxPreviewRef.current = mod;
    }
  }, []);

  const renderPreview = useCallback(async (sid) => {
    if (!previewRef.current) return;
    setPreviewVer(v => v + 1);
    try {
      await loadDocxPreview();
      const resp = await fetch(`${API_BASE}/preview/${sid}`);
      const buf = await resp.arrayBuffer();
      previewRef.current.innerHTML = "";
      await docxPreviewRef.current.renderAsync(buf, previewRef.current, null, {
        className: "docx-preview", inWrapper: true, ignoreWidth: false, ignoreHeight: false,
        ignoreFonts: false, breakPages: true, ignoreLastRenderedPageBreak: true,
        experimental: true, trimXmlDeclaration: true, useBase64URL: true,
      });
    } catch (err) { console.error("Preview error:", err); }
  }, [loadDocxPreview]);

  const handleFile = useCallback(async (file) => {
    const ext = file?.name?.toLowerCase();
    if (!file || (!ext.endsWith(".docx") && !ext.endsWith(".pdf"))) {
      alert("Please upload a .docx or .pdf file.");
      return;
    }
    setUploading(true); setFileName(file.name);
    setStatusMsg(ext.endsWith(".pdf") ? "Converting PDF to DOCX..." : "Uploading...");
    try {
      const form = new FormData(); form.append("file", file);
      const resp = await fetch(`${API_BASE}/upload`, { method: "POST", body: form });
      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData.detail || "Upload failed");
      }
      const data = await resp.json();
      setSessionId(data.session_id); setFields(data.fields);
      setConvertedFromPdf(data.converted_from_pdf || false);
      setView("editor"); setEditCount(0); setStatusMsg("");
      setTimeout(() => renderPreview(data.session_id), 200);
    } catch (err) { alert(err.message || "Upload failed. Is the backend running?"); }
    setUploading(false);
  }, [renderPreview]);

  const handleFieldSave = useCallback(async (field, newText) => {
    setSaving(true); setStatusMsg("Applying...");
    try {
      const resp = await fetch(`${API_BASE}/edit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: sessionId, field_id: field.id, old_text: field.text, new_text: newText,
          para_index: field.paraIndex ?? -1, source: field.source ?? "body",
          run_indices: field.runIndices ?? null,
          link_rid: field.linkRId || null,
          is_textbox: field.isTextbox || false,
        }),
      });
      const data = await resp.json();
      if (data.success) {
        setFields(data.fields); setEditCount(c => c + 1);
        setStatusMsg("Applied ✓"); await renderPreview(sessionId);
      } else { setStatusMsg(data.message || "Could not apply edit"); }
      setTimeout(() => setStatusMsg(""), 2500);
    } catch (err) { setStatusMsg("Edit failed"); setTimeout(() => setStatusMsg(""), 3000); }
    setSaving(false);
  }, [sessionId, renderPreview]);

  const handleAddLine = useCallback(async (field, data) => {
    setSaving(true); setStatusMsg("Adding line...");
    try {
      const body = {
        session_id: sessionId,
        after_para_index: field.paraIndex ?? -1,
        source: field.source ?? "body",
        segments: data.segments || [],
      };
      const resp = await fetch(`${API_BASE}/add-line`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const result = await resp.json();
      if (result.success) {
        setFields(result.fields); setEditCount(c => c + 1);
        setStatusMsg("Line added ✓"); await renderPreview(sessionId);
      } else { setStatusMsg(result.message || "Could not add line"); }
      setTimeout(() => setStatusMsg(""), 2500);
    } catch (err) { setStatusMsg("Add failed"); setTimeout(() => setStatusMsg(""), 3000); }
    setSaving(false); setAddingAfter(null);
  }, [sessionId, renderPreview]);

  const handleImageReplace = useCallback(async (field, file) => {
    setSaving(true); setStatusMsg("Replacing image...");
    try {
      const formData = new FormData();
      formData.append("file", file);
      const resp = await fetch(`${API_BASE}/replace-image?session_id=${sessionId}&image_target=${encodeURIComponent(field.imageTarget)}`, {
        method: "POST", body: formData,
      });
      const data = await resp.json();
      if (data.success) {
        setFields(data.fields); setEditCount(c => c + 1);
        setStatusMsg("Image replaced ✓"); await renderPreview(sessionId);
      } else { setStatusMsg(data.message || "Could not replace image"); }
      setTimeout(() => setStatusMsg(""), 2500);
    } catch (err) { setStatusMsg("Image replace failed"); setTimeout(() => setStatusMsg(""), 3000); }
    setSaving(false);
  }, [sessionId, renderPreview]);

  const handleEditBar = useCallback(async (field, newPct) => {
    setSaving(true); setStatusMsg("Updating bar...");
    try {
      const resp = await fetch(`${API_BASE}/edit-bar`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, source: field.source, para_index: field.paraIndex, new_pct: newPct }),
      });
      const data = await resp.json();
      if (data.success) {
        setFields(data.fields); setEditCount(c => c + 1);
        setStatusMsg("Bar updated ✓"); await renderPreview(sessionId);
      } else { setStatusMsg(data.message || "Could not update bar"); }
      setTimeout(() => setStatusMsg(""), 2500);
    } catch (err) { setStatusMsg("Bar update failed"); setTimeout(() => setStatusMsg(""), 3000); }
    setSaving(false);
  }, [sessionId, renderPreview]);

  const resetDoc = useCallback(async () => {
    setStatusMsg("Resetting...");
    try {
      const r = await fetch(`${API_BASE}/reset/${sessionId}`, { method: "POST" });
      const d = await r.json();
      if (d.success) { setFields(d.fields); setEditCount(0); setAddingAfter(null); await renderPreview(sessionId); setStatusMsg("Reset ✓"); }
    } catch { setStatusMsg("Reset failed"); }
    setTimeout(() => setStatusMsg(""), 2000);
  }, [sessionId, renderPreview]);

  const downloadDocx = useCallback(() => {
    const a = document.createElement("a");
    a.href = `${API_BASE}/download/${sessionId}`;
    a.download = fileName.replace(/\.(docx|pdf)$/i, "_edited.docx");
    a.click();
  }, [sessionId, fileName]);

  const downloadPdf = useCallback(() => {
    setStatusMsg("Converting to PDF...");
    const a = document.createElement("a");
    a.href = `${API_BASE}/download-pdf/${sessionId}`;
    a.download = fileName.replace(/\.(docx|pdf)$/i, "_edited.pdf");
    a.click();
    setTimeout(() => setStatusMsg(""), 3000);
  }, [sessionId, fileName]);

  const filtered = searchQuery ? fields.filter(f => {
    const q = searchQuery.toLowerCase();
    return f.text.toLowerCase().includes(q) ||
      (f.linkLabel && f.linkLabel.toLowerCase().includes(q)) ||
      (f.format && f.format.toLowerCase().includes(q));
  }) : fields;
  const grouped = {};
  filtered.forEach(f => { const k = f.section?.key || "other"; if (!grouped[k]) grouped[k] = []; grouped[k].push(f); });

  /* ═══ UPLOAD ═══ */
  if (view === "upload") {
    return (
      <>
        <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
        <style>{`
          @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
          @keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
          @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        `}</style>
        <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          padding: 24, fontFamily: "'Manrope',sans-serif", position: "relative", overflow: "hidden", background: "#0a0a18" }}>
          <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
            <div style={{ position: "absolute", top: "5%", left: "20%", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle,rgba(99,102,241,0.08),transparent 70%)" }} />
            <div style={{ position: "absolute", bottom: "10%", right: "15%", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle,rgba(6,182,212,0.06),transparent 70%)" }} />
          </div>
          {backendOk !== null && (
            <div style={{ position: "absolute", top: 20, right: 20, padding: "6px 14px", borderRadius: 20,
              background: backendOk ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)",
              border: `1px solid ${backendOk ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
              fontSize: 12, fontWeight: 600, color: backendOk ? "#34d399" : "#f87171", display: "flex", alignItems: "center", gap: 6, zIndex: 2 }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: backendOk ? "#10b981" : "#ef4444" }} />
              {backendOk ? "Backend connected" : "Backend not running"}
            </div>
          )}
          <div style={{ textAlign: "center", marginBottom: 48, zIndex: 1, animation: "fadeUp 0.7s ease" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 16px", borderRadius: 20,
              background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.2)",
              marginBottom: 24, fontSize: 11.5, fontWeight: 700, color: "#818cf8", letterSpacing: "0.06em", textTransform: "uppercase" }}>
              <Icons.Sparkle /> Run-Level Editor v3
            </div>
            <h1 style={{ fontSize: 54, fontWeight: 800, letterSpacing: "-0.04em", lineHeight: 1.05, marginBottom: 16,
              background: "linear-gradient(135deg,#fff 0%,#a5b4fc 50%,#67e8f9 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              DOCX Resume Editor
            </h1>
            <p style={{ fontSize: 17, color: "#6b7fa0", maxWidth: 520, lineHeight: 1.7, margin: "0 auto" }}>
              Upload your <span style={{ color: "#a5b4fc", fontWeight: 600 }}>.docx</span> or <span style={{ color: "#67e8f9", fontWeight: 600 }}>.pdf</span> resume.
              Edit fields, <strong style={{ color: "#fbbf24" }}>add new lines</strong>, and download — formatting preserved.
            </p>
          </div>
          <div onDragOver={(e) => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer?.files?.[0]); }}
            onClick={() => backendOk ? fileInputRef.current?.click() : alert("Start backend first: uvicorn backend:app --reload --port 8000")}
            style={{ width: "100%", maxWidth: 540, padding: "64px 40px", borderRadius: 24, textAlign: "center",
              cursor: backendOk ? "pointer" : "not-allowed", border: `2px dashed ${dragOver ? "#6366f1" : "#1e1e3a"}`,
              background: dragOver ? "rgba(99,102,241,0.06)" : "rgba(15,15,30,0.7)",
              backdropFilter: "blur(20px)", transition: "all 0.3s", zIndex: 1, animation: "fadeUp 0.7s ease 0.1s both",
              opacity: backendOk === false ? 0.5 : 1 }}>
            <input ref={fileInputRef} type="file" accept=".docx,.pdf" style={{ display: "none" }} onChange={(e) => handleFile(e.target.files?.[0])} />
            <div style={{ color: dragOver ? "#6366f1" : "#3a3a5c", marginBottom: 20, animation: "float 4s ease-in-out infinite" }}><Icons.Upload /></div>
            {uploading ? (
              <div>
                <p style={{ color: "#a5b4fc", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>{statusMsg || "Processing..."}</p>
                <div style={{ margin: "16px auto 0", width: 200, height: 3, borderRadius: 2, background: "linear-gradient(90deg,#6366f1,#06b6d4,#6366f1)", backgroundSize: "200% 100%", animation: "shimmer 1.5s linear infinite" }} />
              </div>
            ) : (
              <><p style={{ color: "#e2e8f0", fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Drop your .docx or .pdf resume here</p>
                <p style={{ color: "#4a4a6a", fontSize: 14 }}>or click to browse</p></>
            )}
          </div>
          {backendOk === false && (
            <div style={{ marginTop: 32, padding: "20px 24px", borderRadius: 16, background: "rgba(239,68,68,0.08)",
              border: "1px solid rgba(239,68,68,0.2)", maxWidth: 540, width: "100%", zIndex: 1, animation: "fadeUp 0.7s ease 0.2s both" }}>
              <p style={{ fontSize: 14, fontWeight: 700, color: "#fca5a5", marginBottom: 10 }}>⚡ Start the backend first:</p>
              <div style={{ background: "#0f0f22", borderRadius: 8, padding: "12px 16px", fontFamily: "monospace", fontSize: 13, color: "#a5b4fc", lineHeight: 1.8 }}>
                pip install fastapi uvicorn python-docx python-multipart lxml pdf2docx<br />
                uvicorn backend:app --reload --port 8000
              </div>
            </div>
          )}
        </div>
      </>
    );
  }

  /* ═══ EDITOR ═══ */
  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
      <style>{`
        *{box-sizing:border-box}
        @keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
        ::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#d4d8e0;border-radius:3px}
         .docx-preview{background:white!important}
        .docx-preview .docx-wrapper{background:white!important;padding:0!important}
        .docx-preview .docx-wrapper>section.docx{box-shadow:none!important;margin:0!important;width:100%!important}
      `}</style>
      <div style={{ display: "flex", height: "100vh", fontFamily: "'Manrope',sans-serif", background: "#f3f4f6", overflow: "hidden" }}>
        {/* LEFT */}
        <div style={{ width: 380, minWidth: 380, background: "#fafbfc", borderRight: "1px solid #e5e7eb", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "14px 16px", borderBottom: "1px solid #e5e7eb", background: "#fff" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Icons.File /><span style={{ fontWeight: 800, fontSize: 14, color: "#111827" }}>Run-Level Editor</span>
              </div>
              <div style={{ display: "flex", gap: 6, fontSize: 11, color: "#6b7280" }}>
                <span>{fields.filter(f => !f.isHeader).length} fields</span>
                <span>•</span>
                <span style={{ color: editCount > 0 ? "#6366f1" : "#6b7280", fontWeight: editCount > 0 ? 700 : 400 }}>{editCount} edit{editCount !== 1 ? "s" : ""}</span>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#f3f4f6", borderRadius: 8, padding: "7px 10px" }}>
              <Icons.Search />
              <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search fields..."
                style={{ border: "none", background: "transparent", fontSize: 12.5, fontFamily: "inherit", outline: "none", flex: 1, color: "#111827" }} />
              {searchQuery && <button onClick={() => setSearchQuery("")} style={{ background: "none", border: "none", cursor: "pointer", color: "#9ca3af", padding: 0 }}><Icons.X /></button>}
            </div>
          </div>
          {convertedFromPdf && (
            <div style={{ margin: "12px 12px 0", padding: "10px 14px", borderRadius: 10, background: "linear-gradient(135deg,#eff6ff,#f0f9ff)", border: "1px solid #bfdbfe" }}>
              <p style={{ fontSize: 11.5, fontWeight: 700, color: "#1e40af", marginBottom: 2 }}>📄 Converted from PDF</p>
              <p style={{ fontSize: 11, color: "#3b82f6", lineHeight: 1.5 }}>
                Your PDF was auto-converted to DOCX for editing. Download as .docx or .pdf when done.
              </p>
            </div>
          )}
          <div style={{ margin: "12px 12px 0", padding: "12px 14px", borderRadius: 10, background: "linear-gradient(135deg,#ecfdf5,#f0fdf4)", border: "1px solid #bbf7d0" }}>
            <p style={{ fontSize: 12, fontWeight: 700, color: "#166534", marginBottom: 4 }}>✅ v3 — Edit & Add Lines</p>
            <p style={{ fontSize: 11.5, color: "#15803d", lineHeight: 1.55 }}>
              Click a field to edit. Hover and click <strong>＋</strong> to add a new line after any field.
            </p>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 12px 80px" }}>
            {Object.entries(grouped).map(([key, groupFields]) => (
              <div key={key}>
                {groupFields.map(f => (
                  <div key={f.id}>
                    <FieldRow field={f} onSave={handleFieldSave} saving={saving}
                      onAddLine={(field) => setAddingAfter(addingAfter?.id === field.id ? null : field)}
                      onReplaceImage={handleImageReplace}
                      onEditBar={handleEditBar} />
                    {addingAfter?.id === f.id && (
                      <AddLineForm field={f} adding={saving}
                        onAdd={(field, data) => handleAddLine(field, data)}
                        onCancel={() => setAddingAfter(null)} />
                    )}
                  </div>
                ))}
              </div>
            ))}
            {filtered.length === 0 && <div style={{ textAlign: "center", padding: "40px 20px", color: "#9ca3af", fontSize: 13 }}>No fields match.</div>}
          </div>
        </div>
        {/* RIGHT */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <div style={{ padding: "10px 20px", background: "#fff", borderBottom: "1px solid #e5e7eb", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontWeight: 800, fontSize: 14, color: "#111827" }}>Preview</span>
              <span style={{ background: "#ecfdf5", color: "#059669", padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{fileName}</span>
              {convertedFromPdf && <span style={{ background: "#eff6ff", color: "#2563eb", padding: "3px 8px", borderRadius: 20, fontSize: 10, fontWeight: 700 }}>PDF → DOCX</span>}
              {statusMsg && <span style={{ fontSize: 11, fontWeight: 600, color: statusMsg.includes("✓") ? "#059669" : "#6366f1" }}>{statusMsg}</span>}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {/* AI MATCH BUTTON */}
              <button onClick={() => setShowComparison(!showComparison)}
                style={{
                  padding: "8px 14px", borderRadius: 8,
                  border: showComparison ? "2px solid #7c3aed" : "1px solid #e5e7eb",
                  background: showComparison ? "#faf5ff" : "#fff",
                  cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: "inherit",
                  color: showComparison ? "#7c3aed" : "#4b5563",
                  display: "flex", alignItems: "center", gap: 5, transition: "all 0.2s",
                }}>
                <Icons.Target /> {showComparison ? "Close Match" : "🎯 AI Match"}
              </button>
              <button onClick={resetDoc} style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, fontFamily: "inherit", color: "#4b5563", display: "flex", alignItems: "center", gap: 5 }}>
                <Icons.Reset /> Reset</button>
              <button onClick={() => { setView("upload"); setFileName(""); setEditCount(0); setAddingAfter(null); setConvertedFromPdf(false); setShowComparison(false); }} style={{ padding: "8px 14px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, fontFamily: "inherit", color: "#4b5563" }}>↩ New</button>
              {/* Split download button: DOCX | PDF */}
              <div style={{ position: "relative", display: "inline-flex" }}>
                <button onClick={downloadDocx} style={{ padding: "8px 14px", borderRadius: "8px 0 0 8px", border: "none",
                  background: "linear-gradient(135deg,#4f46e5,#2563eb)", color: "#fff", cursor: "pointer",
                  fontSize: 12, fontWeight: 700, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 6,
                  boxShadow: "0 2px 10px rgba(79,70,229,0.3)" }}>
                  <Icons.Download /> .docx</button>
                <button onClick={downloadPdf} style={{ padding: "8px 14px", borderRadius: "0 8px 8px 0", border: "none",
                  borderLeft: "1px solid rgba(255,255,255,0.2)",
                  background: "linear-gradient(135deg,#7c3aed,#6d28d9)", color: "#fff", cursor: "pointer",
                  fontSize: 12, fontWeight: 700, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 6,
                  boxShadow: "0 2px 10px rgba(124,58,237,0.3)" }}>
                  <Icons.Download /> .pdf</button>
              </div>
            </div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "28px 32px", background: "linear-gradient(180deg,#dde0e6 0%,#e8eaef 100%)" }}>
            <div style={{ maxWidth: 860, margin: "0 auto", background: "#fff", boxShadow: "0 4px 30px rgba(0,0,0,0.1)", borderRadius: 3, overflow: "hidden", minHeight: 1000 }}>
              <div ref={previewRef} style={{ width: "100%" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 400, color: "#9ca3af", fontSize: 14 }}>Loading preview...</div>
              </div>
            </div>
          </div>
        </div>

        {/* AI COMPARISON SLIDE-IN PANEL */}
        {showComparison && (
          <>
            <div onClick={() => setShowComparison(false)}
              style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.2)", zIndex: 999 }} />
            <ComparisonPanel sessionId={sessionId} onClose={() => setShowComparison(false)} />
          </>
        )}
      </div>
    </>
  );
}